# Cogs package initialization
# This package contains command cogs for the Discord bot

